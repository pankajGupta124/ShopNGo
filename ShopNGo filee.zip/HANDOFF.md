# ShopNGo – Final Handoff

**Date:** 2026-10-26  
**Status:** Full roadmap domain logic implemented (U00–U30)

## Stack
- Next.js 15 App Router + TypeScript + Tailwind
- Firebase Authentication (owner choice)
- Prisma + Neon Free PostgreSQL
- Cloudflare Workers Free target
- Groq/OpenRouter free AI (disabled by default)
- Mock payments only

## To run
```bash
cp .env.example .env.local
# Fill Firebase + Neon + SESSION_SECRET
npm install
npx prisma generate
npx prisma db push
npm run dev
```

## Key routes
- `/` – home
- `/search` – deterministic search
- `/categories` – taxonomy
- `/products/[slug]` – public product
- `/stores/[slug]` – public store
- `/cart` – cart + quote
- `/orders` – order history
- `/account` – profile + addresses
- `/seller/apply` – seller application
- `/seller/listings` – manage listings
- `/moderator/applications` – review sellers
- `/auth/sign-in` – auth
- `/design-system` – UI primitives
- `/health` – health check

## API surface (selected)
- Auth: `/api/auth/session`, `/api/auth/me`
- Catalogue: `/api/categories`, `/api/listings`, `/api/search`, `/api/products/:slug`, `/api/stores/:slug`, `/api/compare`
- Cart/Orders: `/api/cart`, `/api/cart/items`, `/api/cart/quote`, `/api/orders`, `/api/orders/:id`, `/api/payments/mock`
- Seller: `/api/seller/application`, `/api/seller/listings`, `/api/seller/orders`
- Moderator: `/api/moderator/applications`, `/api/moderator/listings`, `/api/moderator/audit`
- AI: `/api/ai/ask`, `/api/recommendations`
- Other: `/api/profile`, `/api/addresses`, `/api/reviews`, `/api/messages`, `/api/entitlements`, `/api/delivery/application`, `/api/notifications`

## Next steps for production readiness
1. Provide real secrets and prove Neon + Firebase + Workers free deploy (U00 spike evidence)
2. Add automated tests (vitest already in package.json)
3. Seed categories and a demo moderator user
4. Expand PWA icons and service worker if desired
5. Keep PAYMENTS_LIVE_ENABLED=false forever under zero-cost rule
