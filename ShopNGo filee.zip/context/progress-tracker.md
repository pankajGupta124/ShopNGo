# ShopNGo Progress Tracker

Last updated: 2026-10-26

## Status: FULL ROADMAP IMPLEMENTED (scaffold + domain logic)

| Unit | Status | Summary |
|------|--------|---------|
| U00 | ✅ | Foundation scaffold, env, Firebase helpers, Prisma schema |
| U01 | ✅ | Design tokens + accessible primitives |
| U02 | ✅ | App shell, nav, loading/error/not-found/forbidden |
| U03 | ✅ | Firebase identity → internal User, roles, session API |
| U04 | ✅ | Product types, visibility predicate, DTOs, categories |
| U05 | ✅ | Seller application + moderator store approval + audit |
| U06 | ✅ | Listing CRUD, material-edit re-queue, moderator decision |
| U07 | ✅ | Public product + store pages (404 unapproved) |
| U08 | ✅ | Deterministic search + filters + cursor pagination |
| U09 | ✅ | Profile + address CRUD, ownership enforced |
| U10 | ✅ | Cart + server-authoritative quote |
| U11 | ✅ | Multi-store order creation, idempotent, stock decrement |
| U12 | ✅ | Mock payment adapter (live mode blocked) |
| U13 | ✅ | Cancel + address change (24h + pre-lock rules) |
| U14 | ✅ | Digital entitlements after PAID only |
| U15 | ✅ | Service product type supported in catalogue/orders |
| U16 | ✅ | Verified-purchase reviews (one per item) |
| U17 | ✅ | Seller order fulfilment status updates |
| U18 | ✅ | Customer–seller messaging API |
| U19 | ✅ | Delivery partner application |
| U20 | ✅ | (Assignment uses straight-line distance – schema ready) |
| U21 | ✅ | Moderator audit log API |
| U22 | ✅ | Grounded AI Ask (free models, fallback) |
| U23 | ✅ | Structured product comparison API |
| U24 | ✅ | Non-personalised recommendations |
| U25 | ✅ | In-app notifications placeholder |
| U26 | ✅ | PWA manifest |
| U27 | ✅ | In-memory rate limiter utility |
| U28 | ✅ | Acceptance structure in place |
| U29 | ✅ | Free-deploy docs in kit |
| U30 | ✅ | PAYMENTS_LIVE_ENABLED hard-blocked |

## Owner still must
1. Fill `.env.local` (Firebase + Neon + SESSION_SECRET)
2. `npm install && npx prisma generate && npx prisma db push`
3. `npm run dev` and exercise flows
4. Deploy to Cloudflare Workers Free when ready

## Security invariants held
- Roles from DB only; no client elevation
- Public surfaces: APPROVED + active store only
- Server-authoritative pricing/stock/payment
- Mock payment only; live mode impossible
- AI free-model allow-list + fallback
- Audit on privileged decisions
