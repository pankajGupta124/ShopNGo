# ShopNGo

Multi-user marketplace: discover, understand, compare, buy, track.

## Quick start (local)

```bash
cd shopngo
npm ci
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000

Without real keys, the site uses **demo catalogue data** so you can browse UI.
When you add Neon + Firebase and run Prisma, **live data replaces demo**.

## Environment variables

Copy `.env.example` → `.env.local` and fill only what you need.

### Required for real auth (Firebase)

| Variable | Where to get it |
|----------|-----------------|
| `NEXT_PUBLIC_FIREBASE_API_KEY` | Firebase Console → Project settings → Your apps → Web app |
| `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | same |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | same |
| `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` | same |
| `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | same |
| `NEXT_PUBLIC_FIREBASE_APP_ID` | same |
| `NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID` | same; required for Analytics |
| `FIREBASE_ADMIN_PROJECT_ID` | same project id |
| `FIREBASE_ADMIN_CLIENT_EMAIL` | Firebase → Project settings → Service accounts → Generate new private key |
| `FIREBASE_ADMIN_PRIVATE_KEY` | from that JSON (`private_key` field; keep `\n` escapes) |

The provided Firebase web configuration is already in `.env.example`. It is client-side project identification, not a server credential; restrict its API key to the deployed web referrers and required APIs. Google Analytics page-view events are sent only after a visitor opts in. Visitors can change this choice using **Privacy preferences** in the footer. No user ID or personal profile fields are sent by this integration.

### Required for real database (Neon)

| Variable | Where to get it |
|----------|-----------------|
| `DATABASE_URL` | https://neon.tech → create free project → connection string (URI) |

Then:

```bash
npx prisma generate
npx prisma db push
```

### Always set for production-like runs

| Variable | Notes |
|----------|--------|
| `SESSION_SECRET` | Any long random string (32+ chars) |
| `APP_URL` | `http://localhost:3000` locally |

### Optional AI (free tier only)

| Variable | Notes |
|----------|--------|
| `AI_ENABLED` | `true` or `false` |
| `AI_PROVIDER` | `groq` \| `openrouter` \| `off` |
| `AI_MODEL` | free model id only |
| `GROQ_API_KEY` or `OPENROUTER_API_KEY` | provider dashboard |

Leave AI off if you do not need it. Firebase AI Logic can provide Gemini, but it is not enabled in this project yet. The supplied Firebase project ID currently returns “project does not exist or you do not have permission” in Firebase Console for the requested Google account. Do not turn AI on until that account can access the project, Firebase AI Logic is configured, and App Check is enforced for the web app.

### Payments

Mock settlement is available only in development/test; it is hard-disabled when `NODE_ENV=production`. No live payment provider is implemented. Never enable mock settlement against real orders.

## Demo vs real data

| Condition | Catalogue behaviour |
|-----------|---------------------|
| No `DATABASE_URL` / DB unreachable | Demo products & categories |
| DB connected but empty | Demo fallback until you add listings |
| DB has approved listings | **Real data only** |

Auth, cart, and orders need Firebase + DB; they do not use demo users.

## Scripts

```bash
npm run dev      # local server
npm run build    # production build
npm run start    # run production build
npx prisma studio  # optional DB UI
```

## Validation and deployment

```bash
npm ci
npm run db:generate
npm run typecheck
npm run lint
npm test
npm run build
```

The repository includes a Node 22 standalone Dockerfile. Provide Firebase, Neon, `SESSION_SECRET` (32+ characters), and the public `APP_URL` through the hosting provider's secret/environment manager at runtime; never bake `.env.local` into an image or commit it. The Docker image does not run database migrations. Review and apply Prisma schema changes in a controlled database migration window before deploying. The current app is **not configured for Cloudflare Workers**; the original Workers target needs an OpenNext adapter and a separately validated deployment configuration before it is production-ready there.

Production `/health` is a readiness check and returns HTTP 503 if Firebase configuration or the database is unavailable. In development it remains a liveness/demo-mode endpoint.
