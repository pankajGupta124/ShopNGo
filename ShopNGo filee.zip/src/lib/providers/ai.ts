/**
 * AI Provider boundary – free models only.
 * AI is OFF by default. Never routes to paid models.
 */

const FREE_GROQ_MODELS = [
  "llama-3.1-8b-instant",
  "llama-3.3-70b-versatile",
  "gemma2-9b-it",
  "mixtral-8x7b-32768",
] as const;

const FREE_OPENROUTER_MODELS = [
  "meta-llama/llama-3.1-8b-instruct:free",
  "google/gemma-2-9b-it:free",
  "mistralai/mistral-7b-instruct:free",
] as const;

export type AIProvider = "off" | "groq" | "openrouter";

export function isModelAllowed(provider: AIProvider, modelId: string): boolean {
  if (provider === "off") return false;
  if (provider === "groq") {
    return (FREE_GROQ_MODELS as readonly string[]).includes(modelId);
  }
  if (provider === "openrouter") {
    return (FREE_OPENROUTER_MODELS as readonly string[]).includes(modelId);
  }
  return false;
}

export async function callAI(params: {
  provider: AIProvider;
  model: string;
  prompt: string;
  maxTokens?: number;
}): Promise<{ text: string } | { error: string }> {
  if (params.provider === "off") {
    return { error: "AI is disabled" };
  }

  if (!isModelAllowed(params.provider, params.model)) {
    return {
      error: `Model "${params.model}" is not in the free-model allow-list for ${params.provider}. Paid models are forbidden.`,
    };
  }

  // Actual fetch implementation will be completed when keys are provided.
  // For U00 we only prove the allow-list guard.
  return {
    error: "AI provider call not yet wired – free-model allow-list guard is active.",
  };
}

export function getFreeModelAllowList() {
  return {
    groq: FREE_GROQ_MODELS,
    openrouter: FREE_OPENROUTER_MODELS,
  };
}
