import type { Metadata } from "next";
import { DM_Sans, Outfit } from "next/font/google";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { AuthProvider } from "@/features/identity/AuthProvider";
import { ThemeProvider } from "@/features/theme/ThemeProvider";
import { SkipLink } from "@/components/a11y/SkipLink";
import { OnboardingHint } from "@/components/feedback/OnboardingHint";
import { FirebaseAnalytics } from "@/components/analytics/FirebaseAnalytics";
import "./globals.css";

const sans = DM_Sans({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const display = Outfit({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "ShopNGo",
    template: "%s · ShopNGo",
  },
  description: "Discover. Understand. Compare. Buy. Track.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${sans.variable} ${display.variable} flex min-h-screen flex-col bg-[var(--bg)] text-[var(--fg)] antialiased`}
      >
        <ThemeProvider>
          <AuthProvider>
            <SkipLink />
            <Header />
            <main id="main-content" className="flex-1">
              {children}
            </main>
            <Footer />
            <OnboardingHint />
            <FirebaseAnalytics />
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
