import { NextRequest, NextResponse } from "next/server";
import { prisma, isDatabaseConfigured } from "@/lib/db";
import { getSessionUser } from "@/lib/auth/session";
import { rateLimit } from "@/lib/security/rateLimit";
import { groundedAsk } from "@/features/ai/ask";
import { isPubliclyVisible } from "@/features/catalogue";
import { z } from "zod";

const askSchema = z.object({
  question: z.string().min(3).max(4000),
  listingId: z.string().optional(),
});

/**
 * POST /api/ai/ask
 * Grounded AI Ask – free models only, falls back when unavailable.
 */
export async function POST(req: NextRequest) {
  try {
    const user = await getSessionUser(req.headers.get("authorization"));
    const userLimit = rateLimit(
      `ai:user:${user?.id ?? "guest"}`,
      Number(process.env.AI_USER_DAILY_REQUEST_LIMIT ?? 10),
      86_400_000
    );
    const globalLimit = rateLimit(
      "ai:global",
      Number(process.env.AI_GLOBAL_DAILY_REQUEST_LIMIT ?? 40),
      86_400_000
    );
    if (!userLimit.allowed || !globalLimit.allowed) {
      return NextResponse.json({ error: "Daily AI request limit reached" }, { status: 429 });
    }

    const body = await req.json();
    const parsed = askSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Validation failed", details: parsed.error.flatten() }, { status: 400 });
    }

    const snippets: string[] = [];

    if (isDatabaseConfigured() && prisma) {
      if (parsed.data.listingId) {
        const listing = await prisma.listing.findUnique({
          where: { id: parsed.data.listingId },
          include: { store: true, category: true },
        });
        if (listing && isPubliclyVisible(listing)) {
          snippets.push(
            `Title: ${listing.title}\nType: ${listing.productType}\nPrice: ${listing.currency} ${listing.price}\nDescription: ${listing.description ?? "N/A"}\nStore: ${listing.store.name}`
          );
        }
      } else {
        // Search top matching approved listings
        const listings = await prisma.listing.findMany({
          where: {
            status: "APPROVED",
            store: { isActive: true },
            OR: [
              { title: { contains: parsed.data.question.slice(0, 50), mode: "insensitive" } },
              { description: { contains: parsed.data.question.slice(0, 50), mode: "insensitive" } },
            ],
          },
          include: { store: true },
          take: 5,
        });
        for (const l of listings) {
          if (isPubliclyVisible(l)) {
            snippets.push(
              `Title: ${l.title}\nType: ${l.productType}\nPrice: ${l.currency} ${l.price}\nStore: ${l.store.name}`
            );
          }
        }
      }
    }

    const result = await groundedAsk(parsed.data.question, snippets);
    return NextResponse.json(result);
  } catch (err) {
    console.error("ai ask error:", err instanceof Error ? err.message : err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
