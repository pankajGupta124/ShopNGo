import { NextResponse } from "next/server";
import { prisma, isDatabaseConfigured } from "@/lib/db";
import {
  filterPublicListings,
  toPublicListingDTO,
} from "@/features/catalogue";
import { DEMO_LISTINGS } from "@/lib/demo-data";

export async function GET() {
  if (!isDatabaseConfigured() || !prisma) {
    return NextResponse.json({
      recommendations: DEMO_LISTINGS.slice(0, 6).map((l) => ({
        ...l,
        reason: "Popular on ShopNGo",
      })),
      source: "demo",
    });
  }

  try {
    const listings = await prisma.listing.findMany({
      where: { status: "APPROVED", store: { isActive: true } },
      include: {
        store: {
          select: { id: true, name: true, slug: true, isActive: true },
        },
        category: { select: { id: true, name: true, slug: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 12,
    });

    const visible = filterPublicListings(listings);
    if (visible.length === 0) {
      return NextResponse.json({
        recommendations: DEMO_LISTINGS.slice(0, 6).map((l) => ({
          ...l,
          reason: "Popular on ShopNGo",
        })),
        source: "demo-fallback",
      });
    }

    return NextResponse.json({
      recommendations: visible.map((l) => ({
        ...toPublicListingDTO(l),
        reason: "Recently added",
      })),
      source: "database",
    });
  } catch {
    return NextResponse.json({
      recommendations: DEMO_LISTINGS.slice(0, 6).map((l) => ({
        ...l,
        reason: "Popular on ShopNGo",
      })),
      source: "demo-fallback",
    });
  }
}
