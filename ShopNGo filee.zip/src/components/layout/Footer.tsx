import Link from "next/link";
import { AnalyticsPreferencesButton } from "@/components/analytics/FirebaseAnalytics";

export function Footer() {
  return (
    <footer className="mt-auto border-t border-teal-900/10 bg-gradient-to-b from-gray-50 to-gray-100/80 dark:border-zinc-800 dark:from-zinc-950 dark:to-zinc-900">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 sm:py-14">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-teal-500 to-teal-800 text-white shadow-md" aria-hidden="true">
                <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M5 8h14l1 13H4L5 8Z" />
                  <path d="M9 9V6a3 3 0 0 1 6 0v3" />
                </svg>
              </span>
              <span className="font-display text-lg font-bold text-teal-900 dark:text-teal-300">
                Shop<span className="text-teal-600">NGo</span>
              </span>
            </div>
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-gray-600 dark:text-zinc-400">
              Discover. Understand. Compare. Buy. Track.
            </p>
            {/* Trust badges */}
            <ul className="mt-5 flex flex-wrap gap-2" aria-label="Trust signals">
              {["Verified sellers", "Secure checkout", "Order tracking"].map(
                (label) => (
                  <li
                    key={label}
                    className="rounded-full border border-teal-200 bg-teal-50/80 px-2.5 py-1 text-[11px] font-medium text-teal-800 dark:border-teal-900 dark:bg-teal-950 dark:text-teal-300"
                  >
                    {label}
                  </li>
                )
              )}
            </ul>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-teal-800/80 dark:text-teal-500/90">
              Shop
            </p>
            <ul className="mt-3 space-y-2.5 text-sm text-gray-600 dark:text-zinc-400">
              <li>
                <Link href="/search" className="hover:text-teal-700 dark:hover:text-teal-400">
                  Search
                </Link>
              </li>
              <li>
                <Link href="/categories" className="hover:text-teal-700 dark:hover:text-teal-400">
                  Categories
                </Link>
              </li>
              <li>
                <Link href="/cart" className="hover:text-teal-700 dark:hover:text-teal-400">
                  Cart
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-teal-800/80 dark:text-teal-500/90">
              Account
            </p>
            <ul className="mt-3 space-y-2.5 text-sm text-gray-600 dark:text-zinc-400">
              <li>
                <Link href="/auth/sign-in" className="hover:text-teal-700 dark:hover:text-teal-400">
                  Sign in
                </Link>
              </li>
              <li>
                <Link href="/account" className="hover:text-teal-700 dark:hover:text-teal-400">
                  Profile
                </Link>
              </li>
              <li>
                <Link href="/orders" className="hover:text-teal-700 dark:hover:text-teal-400">
                  Orders
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-teal-800/80 dark:text-teal-500/90">
              Sell
            </p>
            <ul className="mt-3 space-y-2.5 text-sm text-gray-600 dark:text-zinc-400">
              <li>
                <Link href="/seller/apply" className="hover:text-teal-700 dark:hover:text-teal-400">
                  Become a seller
                </Link>
              </li>
              <li>
                <Link href="/seller/listings" className="hover:text-teal-700 dark:hover:text-teal-400">
                  Manage listings
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-12 border-t border-gray-200/90 pt-6 text-center text-xs text-gray-500 dark:border-zinc-800 dark:text-zinc-500">
          © {new Date().getFullYear()} ShopNGo. All rights reserved.
          <div className="mt-1">
            <AnalyticsPreferencesButton />
          </div>
        </div>
      </div>
    </footer>
  );
}
