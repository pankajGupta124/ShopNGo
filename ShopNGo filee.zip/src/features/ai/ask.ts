/**
 * Grounded AI Ask – free models only, catalogue-grounded.
 * Falls back to deterministic search when AI is disabled or rate-limited.
 */

import { isModelAllowed, callAI } from "@/lib/providers/ai";
import { getServerEnv } from "@/lib/env";

export async function groundedAsk(question: string, contextSnippets: string[]): Promise<{
  answer: string;
  evidence: string[];
  source: "ai" | "fallback";
}> {
  const env = getServerEnv();
  const evidence = contextSnippets.slice(0, 5);

  if (!env.AI_ENABLED || env.AI_PROVIDER === "off") {
    return {
      answer: "AI is currently disabled. Please use the search page to find products.",
      evidence,
      source: "fallback",
    };
  }

  if (!isModelAllowed(env.AI_PROVIDER, env.AI_MODEL ?? "")) {
    return {
      answer: "Configured AI model is not in the free-model allow-list. Using search fallback.",
      evidence,
      source: "fallback",
    };
  }

  const prompt = `You are ShopNGo catalogue assistant. Answer ONLY from the evidence below. If the answer is not in the evidence, say "Not provided in catalogue data."\n\nEvidence:\n${evidence.join("\n---\n")}\n\nQuestion: ${question}`;

  const result = await callAI({
    provider: env.AI_PROVIDER,
    model: env.AI_MODEL ?? "",
    prompt,
    maxTokens: env.AI_MAX_OUTPUT_TOKENS ? Number(env.AI_MAX_OUTPUT_TOKENS) : 512,
  });

  if ("error" in result) {
    return {
      answer: `AI unavailable (${result.error}). Please use search instead.`,
      evidence,
      source: "fallback",
    };
  }

  return { answer: result.text, evidence, source: "ai" };
}
